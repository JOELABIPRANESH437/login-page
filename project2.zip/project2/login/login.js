const form = document.getElementById('loginform');

form.addEventListener('submit', function(event) {
    event.preventDefault();

    let storedEmail = localStorage.getItem("email");
    let storedPassword = localStorage.getItem("password");


    const email = document.getElementById('email');
    const emailError = document.getElementById('emailError');
    const password = document.getElementById('password');
    const passwordError = document.getElementById('passwordError');
    
    // Check if email or password fields are empty
    let valid = true;

    if (email.value.trim() === '') {
        emailError.textContent = 'Email is required';
        emailError.style.display = 'block';
        valid = false;
    } else {
        emailError.style.display = 'none';
    }

    if (password.value.trim() === '') {
        passwordError.textContent = 'Password is required';
        passwordError.style.display = 'block';
        valid = false;
    } else {
        passwordError.style.display = 'none';
    }
    if (valid) {
        if (email.value.trim() === storedEmail && password.value.trim() === storedPassword) {
            alert("Successfully Logged In");
            window.location.href = "/webpage/index.html";
        } else {
            alert("Invalid Email or Password. Please enter correct input.");
        }
    }
});
