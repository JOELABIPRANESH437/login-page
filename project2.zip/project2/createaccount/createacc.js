const form = document.getElementById('signupForm');

form.addEventListener('submit', function(event) {
    event.preventDefault(); 

    
    let isValid = true;

    
    const firstName = document.getElementById('firstName').value;
    const firstNameError = document.getElementById('firstNameError');
    if (firstName.trim() === '') {
        firstNameError.style.display = 'block';
        isValid = false; 
    } else {
        firstNameError.style.display = 'none';
    }

    
    const lastName = document.getElementById('lastName').value;
    const lastNameError = document.getElementById('lastNameError');
    if (lastName.trim() === '') {
        lastNameError.style.display = 'block';
        isValid = false;
    } else {
        lastNameError.style.display = 'none';
    }

    
    const mobile = document.getElementById('mobile').value;
    const mobileError = document.getElementById('mobileError');
    if (mobile.trim() === '') {
        mobileError.textContent = 'Mobile number is required.';
        mobileError.style.display = 'block';
        isValid = false;
    } else if (mobile.trim().length !== 10 || isNaN(mobile.trim())) {
        mobileError.textContent = 'Only numbers and 10 digits';
        mobileError.style.display = 'block';
        isValid = false;
    } else {
        mobileError.style.display = 'none';
    }

   
    const email = document.getElementById('email').value;
    const emailError = document.getElementById('emailError');
    const emailPattern = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/; 

    if (email.trim() === '') {
    emailError.textContent = 'Email is required.';
    emailError.style.display = 'block';
    isValid = false;
    } 
    else if (!emailPattern.test(email)) {
    emailError.textContent = 'Please enter a valid email address. (ex: example@gmail.com)';
    emailError.style.display = 'block';
    isValid = false;
    } 
    else {
    emailError.style.display = 'none';
    }



   
    const password = document.getElementById('password').value;
    const passwordError = document.getElementById('passwordError');
    if (password.trim() === '') {
        passwordError.textContent = 'Password is required.';
        passwordError.style.display = 'block';
        isValid = false;
    } else if (password.trim().length < 8) {
        passwordError.textContent = 'Password should be at least 8 characters long.';
        passwordError.style.display = 'block';
        isValid = false;
    } else {
        passwordError.style.display = 'none';
    }

    
    const confirmPassword = document.getElementById('confirmPassword').value;
    const confirmPasswordError = document.getElementById('confirmPasswordError');
    if (confirmPassword.trim() === '') {
        confirmPasswordError.textContent = 'Please enter the password.';
        confirmPasswordError.style.display = 'block';
        isValid = false;
    } else if (confirmPassword.trim() !== password.trim()) {
        confirmPasswordError.textContent = 'Passwords do not match.';
        confirmPasswordError.style.display = 'block';
        isValid = false;
    } else {
        confirmPasswordError.style.display = 'none';
    }

    
    if (!isValid) {
        alert("Please correct the highlighted errors and try again.");
    } else {
       
        localStorage.setItem('firstname', firstName);
        localStorage.setItem('lastname', lastName);
        localStorage.setItem('mobile', mobile);
        localStorage.setItem('email', email);
        localStorage.setItem('password', password);
        localStorage.setItem('confirmPassword', confirmPassword);

      
        window.location.href = "/login/login.html";
    }
});
